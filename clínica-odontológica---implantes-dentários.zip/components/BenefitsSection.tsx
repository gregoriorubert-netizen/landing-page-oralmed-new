
import React from 'react';

const BenefitItem: React.FC<{ icon: string; title: string; children: React.ReactNode }> = ({ icon, title, children }) => (
    <div className="flex items-start space-x-4 mb-6">
        <div className="flex-shrink-0">
            <div className="bg-blue-100 rounded-full h-12 w-12 flex items-center justify-center">
                <i className={`fas ${icon} text-2xl text-blue-600`}></i>
            </div>
        </div>
        <div>
            <h3 className="text-xl font-bold text-blue-900 mb-1">{title}</h3>
            <p className="text-gray-600">{children}</p>
        </div>
    </div>
);


const BenefitsSection: React.FC = () => {
    return (
        <section className="py-16 md:py-20 bg-white">
            <div className="container mx-auto px-6">
                <div className="max-w-4xl mx-auto">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800">Vantagens que Transformam seu Sorriso</h2>
                        <p className="text-lg text-slate-600 mt-4">O implante dentário vai além da estética. É um investimento em qualidade de vida, conforto e bem-estar.</p>
                    </div>
                    
                    <div>
                        <BenefitItem icon="fa-smile-beam" title="Estética Natural e Confiança">
                            Os implantes são projetados para se parecerem e funcionarem como dentes naturais, devolvendo a confiança para sorrir sem medo.
                        </BenefitItem>

                         <BenefitItem icon="fa-utensils" title="Melhora na Mastigação">
                            Recupere a capacidade de comer seus alimentos favoritos com conforto e segurança, sem as limitações de próteses móveis.
                        </BenefitItem>

                        <BenefitItem icon="fa-shield-alt" title="Durabilidade e Segurança">
                            Feitos de titânio, um material biocompatível, os implantes se integram ao osso, oferecendo uma solução robusta e de longa duração.
                        </BenefitItem>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default BenefitsSection;
