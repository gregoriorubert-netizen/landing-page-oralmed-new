
import React from 'react';
import { WHATSAPP_NUMBER, WHATSAPP_MESSAGE } from '../constants';

interface CTAButtonProps {
  text: string;
  className?: string;
  icon?: boolean;
}

const CTAButton: React.FC<CTAButtonProps> = ({ text, className = '', icon = true }) => {
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center justify-center px-8 py-4 bg-green-500 text-white font-bold text-lg rounded-lg shadow-lg hover:bg-green-600 transition-transform duration-300 transform hover:scale-105 ${className}`}
    >
      {icon && <i className="fab fa-whatsapp mr-3 text-2xl"></i>}
      {text}
    </a>
  );
};

export default CTAButton;
