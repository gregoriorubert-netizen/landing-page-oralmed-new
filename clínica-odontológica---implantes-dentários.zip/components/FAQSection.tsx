
import React, { useState } from 'react';

const FAQItem: React.FC<{ question: string; children: React.ReactNode }> = ({ question, children }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="border-b border-gray-200 py-4">
            <button
                className="w-full flex justify-between items-center text-left text-lg font-bold text-slate-800 focus:outline-none"
                onClick={() => setIsOpen(!isOpen)}
            >
                <span>{question}</span>
                <i className={`fas fa-chevron-down transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}></i>
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96 mt-4' : 'max-h-0'}`}>
                <div className="text-gray-600 leading-relaxed">
                    {children}
                </div>
            </div>
        </div>
    );
};

const FAQSection: React.FC = () => {
    return (
        <section className="py-16 md:py-20 bg-white">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800">Tem dúvidas se o Implante Dentário é para você?</h2>
                    <p className="text-lg text-slate-600 mt-4">Separamos as perguntas mais comuns para te ajudar.</p>
                </div>
                <div className="max-w-3xl mx-auto">
                    <FAQItem question="Qual o implante ideal para o meu caso?">
                        <p>A escolha do implante ideal depende de vários fatores, como a quantidade de dentes a serem substituídos, a saúde óssea da sua mandíbula e suas expectativas estéticas. Somente uma avaliação detalhada com um especialista, incluindo exames de imagem, pode determinar o tipo de implante, prótese e técnica mais adequados para garantir um resultado seguro e duradouro. Agende uma consulta para criarmos seu plano de tratamento personalizado.</p>
                    </FAQItem>
                    <FAQItem question="Como funciona o procedimento de implante dentário?">
                        <p>O procedimento é realizado em etapas. Primeiro, é feita uma cirurgia para instalar o pino de titânio no osso maxilar. Após um período de cicatrização (osseointegração), uma prótese dentária (dente artificial) é conectada a este pino. O processo é realizado com anestesia local, garantindo que seja indolor e confortável para o paciente. Nossa equipe explicará cada passo em detalhes na sua consulta de avaliação.</p>
                    </FAQItem>
                    <FAQItem question="Quanto custa um implante dentário?">
                        <p>O valor de um implante dentário varia significativamente dependendo da complexidade do caso, do tipo de implante e da prótese utilizada, além da necessidade de procedimentos adicionais como enxertos ósseos. Por isso, é impossível fornecer um preço sem uma avaliação clínica. Nosso compromisso é oferecer um tratamento de alta qualidade com um valor justo e condições de pagamento facilitadas. Agende sua avaliação para receber um orçamento completo e sem compromisso.</p>
                    </FAQItem>
                </div>
            </div>
        </section>
    );
};

export default FAQSection;
