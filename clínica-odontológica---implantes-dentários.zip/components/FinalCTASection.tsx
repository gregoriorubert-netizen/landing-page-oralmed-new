
import React from 'react';
import CTAButton from './CTAButton';

const FinalCTASection: React.FC = () => {
  return (
    <section className="bg-blue-600 text-white py-16 md:py-20">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-extrabold mb-4">
          Quer um atendimento imediato para falar sobre Implante Dentário?
        </h2>
        <p className="text-lg md:text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
          Fale agora com nossa equipe especializada pelo WhatsApp e dê o primeiro passo para renovar seu sorriso com segurança e conforto.
        </p>
        <CTAButton 
            text="Agendar consulta de implante"
        />
      </div>
    </section>
  );
};

export default FinalCTASection;
