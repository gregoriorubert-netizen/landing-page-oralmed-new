
import React from 'react';
import { CLINIC_NAME, CITY_NAME } from '../constants';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-blue-900 text-white py-8">
      <div className="container mx-auto px-6 text-center">
        <p>&copy; {currentYear} {CLINIC_NAME}. Todos os direitos reservados.</p>
        <p className="text-sm text-blue-200 mt-2">Implantes Dentários de alta qualidade em {CITY_NAME}.</p>
      </div>
    </footer>
  );
};

export default Footer;
