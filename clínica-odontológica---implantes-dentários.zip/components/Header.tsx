
import React from 'react';
import { CLINIC_NAME } from '../constants';

const Header: React.FC = () => {
  return (
    <header className="bg-white py-4 px-6 md:px-12 shadow-sm sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
            <img src="https://i.imgur.com/PlFR3YN.png" alt={`${CLINIC_NAME} Logo`} className="h-12" />
        </div>
        <p className="text-sm text-blue-700 font-semibold hidden sm:block">Especialistas em Reabilitação Oral</p>
      </div>
    </header>
  );
};

export default Header;
