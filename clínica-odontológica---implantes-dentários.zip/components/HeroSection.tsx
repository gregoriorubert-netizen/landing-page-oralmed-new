
import React from 'react';
import CTAButton from './CTAButton';
import { CITY_NAME } from '../constants';

const HeroSection: React.FC = () => {
  return (
    <section className="bg-blue-50 py-16 md:py-24">
      <div className="container mx-auto px-6 text-center">
        <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-left">
                <h1 className="text-4xl md:text-5xl font-black text-slate-800 leading-tight mb-4">
                    Implantes Dentários em <span className="text-blue-500">{CITY_NAME}</span> com Especialistas em Reabilitação Oral
                </h1>
                <p className="text-lg text-slate-600 mb-8">
                    Recupere seu sorriso, mastigação e autoestima com segurança e planejamento personalizado.
                </p>
                <CTAButton text="Agendar consulta de implante" />
            </div>
            <div>
                 <img 
                    src="https://imgur.com/5UMyMRQ.jpg"
                    alt="Paciente com sorriso perfeito após implante dentário" 
                    className="rounded-lg shadow-2xl mx-auto w-full max-w-lg"
                 />
            </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
