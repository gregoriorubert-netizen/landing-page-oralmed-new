
import React from 'react';

const StepCard: React.FC<{ icon: string; title: string; description: string; stepNumber: string }> = ({ icon, title, description, stepNumber }) => (
    <div className="relative bg-white p-6 rounded-lg shadow-md text-center border-t-4 border-blue-500">
        <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-blue-600 text-white rounded-full h-12 w-12 flex items-center justify-center font-bold text-xl">
            {stepNumber}
        </div>
        <div className="mt-8">
            <i className={`fas ${icon} text-4xl text-blue-500 mb-4`}></i>
            <h3 className="text-xl font-bold text-blue-900 mb-2">{title}</h3>
            <p className="text-gray-600">{description}</p>
        </div>
    </div>
);


const HowItWorksSection: React.FC = () => {
  return (
    <section className="py-16 md:py-20 bg-gray-50">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800 mb-4">Como funciona o agendamento da sua consulta de avaliação</h2>
        <p className="text-lg text-slate-600 mb-12 max-w-3xl mx-auto">Nosso processo é simples e focado em oferecer a melhor experiência para você desde o primeiro contato.</p>
        <div className="grid md:grid-cols-3 gap-12 mt-10">
            <StepCard 
                stepNumber="1"
                icon="fa-calendar-check"
                title="Agendamento"
                description="Entre em contato via WhatsApp ou preencha nosso formulário para marcar sua consulta inicial."
            />
            <StepCard 
                stepNumber="2"
                icon="fa-user-md"
                title="Avaliação com Especialista"
                description="Nossos especialistas farão uma avaliação completa para criar um planejamento personalizado para seu caso."
            />
            <StepCard 
                stepNumber="3"
                icon="fa-smile-beam"
                title="Realização do Procedimento"
                description="Com tudo planejado, realizamos o procedimento para você recuperar a função e a estética do seu sorriso."
            />
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
