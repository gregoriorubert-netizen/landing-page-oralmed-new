
import React from 'react';
import CTAButton from './CTAButton';

const ImplantCard: React.FC<{ icon?: string; imageUrl?: string; title: string; description: string }> = ({ icon, imageUrl, title, description }) => (
    <div className="bg-white p-8 rounded-lg shadow-lg text-center transform hover:-translate-y-2 transition-transform duration-300">
        {imageUrl ? (
            <img src={imageUrl} alt={title} className="w-[233px] h-[183px] mx-auto mb-6 object-contain" />
        ) : (
            <div className="bg-blue-100 rounded-full h-20 w-20 flex items-center justify-center mx-auto mb-6">
                <i className={`fas ${icon} text-4xl text-blue-600`}></i>
            </div>
        )}
        <h3 className="text-2xl font-bold text-blue-900 mb-3">{title}</h3>
        <p className="text-gray-600">{description}</p>
    </div>
);

const ImplantTypesSection: React.FC = () => {
  return (
    <section className="py-16 md:py-20 bg-white">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800 mb-12">Confira os tipos de Implante Dentário</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <ImplantCard 
            imageUrl="https://i.imgur.com/VWwEp7w.png"
            title="Implante Unitário"
            description="A solução ideal para substituir a perda de um único dente, restaurando a estética e função."
          />
          <ImplantCard 
            imageUrl="https://i.imgur.com/wCtqlUw.png"
            title="Prótese Fixa (Protocolo)"
            description="Substitui todos os dentes de uma arcada, fixada sobre implantes para máxima estabilidade."
          />
          <ImplantCard 
            imageUrl="https://i.imgur.com/5ZOhI0K.png"
            title="Carga Imediata"
            description="Permite a instalação da prótese provisória logo após a cirurgia do implante, em casos selecionados."
          />
          <ImplantCard 
            imageUrl="https://i.imgur.com/jTDjYYl.png"
            title="Estética Dental"
            description="Focado em harmonizar o sorriso, integrando o implante perfeitamente aos dentes naturais."
          />
        </div>
        <div className="mt-16">
          <CTAButton text="Agendar consulta de implante" />
        </div>
      </div>
    </section>
  );
};

export default ImplantTypesSection;
