
import React from 'react';
import { CITY_NAME } from '../constants';

const TestimonialsSection: React.FC = () => {
    return (
        <section className="py-16 md:py-20 bg-blue-50">
            <div className="container mx-auto px-6">
                <div className="max-w-4xl mx-auto">
                    <div className="text-center mb-10">
                        <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800">Veja a Diferença no Sorriso dos Nossos Pacientes</h2>
                    </div>
                    <div className="bg-white p-8 rounded-lg shadow-lg">
                        <i className="fas fa-quote-left text-3xl text-blue-300 mb-4"></i>
                        <p className="text-lg text-gray-700 italic mb-6">
                            "Eu não tinha mais confiança para sorrir em fotos. Depois do implante, tudo mudou. O procedimento foi muito mais tranquilo do que eu imaginava e o resultado ficou perfeito, super natural. Só tenho a agradecer a toda a equipe pelo profissionalismo e cuidado."
                        </p>
                        <p className="text-right font-bold text-blue-800 text-lg">- Maria S., Paciente de {CITY_NAME}</p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default TestimonialsSection;
