
import React from 'react';

const CheckListItem: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <li className="flex items-start space-x-3 mb-4">
        <div className="flex-shrink-0">
            <i className="fas fa-check-circle text-green-500 text-xl mt-1"></i>
        </div>
        <span className="text-lg text-gray-700">{children}</span>
    </li>
);

const WhoIsItForSection: React.FC = () => {
    return (
        <section className="py-16 md:py-20 bg-blue-50">
            <div className="container mx-auto px-6">
                <div className="grid md:grid-cols-2 gap-12 items-center">
                    <div className="pr-0 md:pr-10">
                        <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800 mb-6">Para quem é o procedimento de Implante Dentário?</h2>
                        <p className="text-lg text-slate-600 mb-8">O implante dentário é uma tecnologia avançada que devolve a qualidade de vida para muitas pessoas. Veja se você se identifica:</p>
                        <ul>
                            <CheckListItem>Pessoas que perderam um ou mais dentes e buscam uma solução permanente.</CheckListItem>
                            <CheckListItem>Quem deseja substituir dentaduras removíveis por uma opção fixa e confortável.</CheckListItem>
                            <CheckListItem>Quem busca uma solução definitiva e com resultado estético natural para o sorriso.</CheckListItem>
                            <CheckListItem>Quem quer restaurar completamente a função mastigatória e a confiança para sorrir.</CheckListItem>
                        </ul>
                    </div>
                    <div>
                        <img 
                            src="https://i.imgur.com/5UMyMRQ.jpg" 
                            alt="Demonstração do procedimento de implante dentário" 
                            className="rounded-lg shadow-xl"
                        />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default WhoIsItForSection;
