
export const CITY_NAME = "Londrina"; // Substitua pela sua cidade
export const CLINIC_NAME = "Oralmed"; // Substitua pelo nome da sua clínica
export const WHATSAPP_NUMBER = "5511999998888"; // Use o formato internacional sem '+' ou '()'
export const WHATSAPP_MESSAGE = "Olá! Gostaria de agendar uma consulta de avaliação para implante dentário.";